import tokenAuth from './tokenAuth';

export default tokenAuth;
